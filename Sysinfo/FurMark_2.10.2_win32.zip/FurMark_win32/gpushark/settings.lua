-- GPU Shark FM2 Edition 2.10.0.0 settings file.
--
-- Check for new version (true or false).
check_version = false
-- Horizontal splitting size if more than one GPU.
gpu_h_split_size = 720
-- Height of GPU data in GPU tab.
gpu_data_view_height = 0
-- Energy computing update interval in seconds.
gpu_energy_compute_interval = 10.0
